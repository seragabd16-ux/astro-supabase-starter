
# PalStyle — 3D Motion Storefront (React + Vite + Tailwind)

**Features**
- 3D beveled hero card, soft motion
- Category highlights, filters, search, sort
- CSV import (Trendyol export)
- PDP modal with size/qty, Add-to-Cart
- Google Sheets webhook with retry + toasts
- Smoke tests section

## Local dev
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Deploy to Netlify
- Create new site from this folder
- Build command: `npm run build`
- Publish dir: `dist/`
- Optional: add a custom domain

### Configure brand logo
Put your SVG/PNG in `public/` and set:
```html
<script>
  window.PALSTYLE_CONFIG = { LOGO_URL: "/your-logo.svg" }
</script>
```
in `index.html` (before the main script).
