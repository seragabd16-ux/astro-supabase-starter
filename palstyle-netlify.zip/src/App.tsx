
import React, { useEffect, useMemo, useRef, useState } from "react";

/* -----------------------------------------------------------------
  PalStyle — 3D Motion Storefront (React + TS)
  • TailwindCSS required (included)
------------------------------------------------------------------ */

/* ==================== Utilities ==================== */
const currency = (v: number) => {
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency: "TRY",
      maximumFractionDigits: 0,
    }).format(v);
  } catch {
    return `₺${v}`;
  }
};

/** Parse TRY price strings: "₺1.299", "1.299,00", "1299", "1,299" */
const toNumber = (price: unknown): number => {
  if (typeof price === "number") return isFinite(price) ? price : 0;
  if (typeof price !== "string") return 0;
  let s = price.trim().replace(/[₺\s]/g, "");
  const hasComma = s.includes(",");
  const hasDot = s.includes(".");
  if (hasComma && hasDot) s = s.replace(/\./g, "").replace(",", ".");
  else if (hasComma && !hasDot) {
    const parts = s.split(",");
    if (parts.length === 2 && parts[1].length <= 2) s = parts[0].replace(/\./g, "") + "." + parts[1];
    else s = s.replace(/,/g, "");
  } else {
    s = s.replace(/\./g, "");
  }
  const n = Number(s.replace(/[^0-9.]/g, ""));
  return isFinite(n) ? n : 0;
};

function uniq<T>(arr: readonly T[] | undefined | null): T[] {
  return Array.from(new Set(arr ?? [])) as T[];
}

/* ==================== Brand Config ==================== */
const BRAND_CONFIG = {
  LOGO_URL: (typeof window !== "undefined" && (window as any).PALSTYLE_CONFIG?.LOGO_URL) || "/palstyle-logo.svg",
};
const getLogo = () => BRAND_CONFIG.LOGO_URL;

/* ==================== Types ==================== */
export type Product = {
  id: number;
  name: string;
  price: string | number;
  tag: string;
  color: string;
  category: string;
  subcategory?: string;
  sizes?: string[];
  sku: string;
  image_url?: string;
};

export type Highlight = {
  key: string;
  label: string;
  category: string | null;
  icon: string;
  subcategory?: string;
};

/* ==================== Seed Data ==================== */
const seedProducts: Product[] = [
  { id: 1, name: "Keffiyeh Hoodie", price: "₺1199", tag: "New", color: "#0f0f10", category: "Winter", subcategory: "Hoodie", sizes: ["S","M","L","XL"], sku: "KH-001" },
  { id: 2, name: "Freedom Tee", price: "₺499", tag: "Best", color: "#151517", category: "Summer", subcategory: "Tee", sizes: ["S","M","L","XL"], sku: "FT-002" },
  { id: 3, name: "Heritage Cap", price: "₺349", tag: "Drop", color: "#0e1111", category: "Accessories", subcategory: "Cap", sizes: ["OS"], sku: "HC-003" },
  { id: 4, name: "Patterned Tote", price: "₺399", tag: "Limited", color: "#111113", category: "Bags", subcategory: "Tote", sizes: ["OS"], sku: "PT-004" },
  { id: 5, name: "Classic Hoodie", price: "₺1099", tag: "New", color: "#121214", category: "Winter", subcategory: "Hoodie", sizes: ["S","M","L","XL"], sku: "CH-005" },
  { id: 6, name: "Zip Jacket", price: "₺1299", tag: "New", color: "#131313", category: "Winter", subcategory: "Jacket", sizes: ["M","L","XL"], sku: "ZJ-006" },
  { id: 7, name: "Sweatshirt No Hood", price: "₺899", tag: "New", color: "#141414", category: "Winter", subcategory: "Sweatshirt", sizes: ["S","M","L","XL"], sku: "SW-007" },
  { id: 8, name: "Keffiyeh Bandana", price: "₺199", tag: "Best", color: "#101112", category: "Keffiyeh", subcategory: "Bandana", sizes: ["OS"], sku: "KB-008" },
  { id: 9, name: "Gym Tee", price: "₺449", tag: "Drop", color: "#0f1112", category: "Sports", subcategory: "Tee", sizes: ["S","M","L","XL"], sku: "GT-009" },
  { id: 10, name: "PalStyle Scarf", price: "₺279", tag: "Best", color: "#0f1011", category: "Accessories", subcategory: "Scarf", sizes: ["OS"], sku: "PS-010" },
  { id: 11, name: "Heritage Hoodie", price: "₺1299", tag: "Drop", color: "#0e0f10", category: "Winter", subcategory: "Hoodie", sizes: ["S","M","L","XL"], sku: "HH-011" },
  { id: 12, name: "Minimal Tote", price: "₺329", tag: "New", color: "#121212", category: "Bags", subcategory: "Tote", sizes: ["OS"], sku: "MT-012" },
];

/* ==================== Highlights ==================== */
const HIGHLIGHTS: Highlight[] = [
  { key: "winter", label: "شتوي", category: "Winter", icon: "snow" },
  { key: "summer", label: "صيفي", category: "Summer", icon: "sun" },
  { key: "hoodies", label: "هودي", category: "Winter", subcategory: "Hoodie", icon: "hoodie" },
  { key: "sweat", label: "سويت شيرت", category: "Winter", subcategory: "Sweatshirt", icon: "hoodie" },
  { key: "jacket", label: "جاكيت/سحاب", category: "Winter", subcategory: "Jacket", icon: "hoodie" },
  { key: "bags", label: "شُنَط", category: "Bags", icon: "bag" },
  { key: "acc", label: "أكسسوارات & فضة", category: "Accessories", icon: "ring" },
  { key: "keff", label: "كوفية & بندانة", category: "Keffiyeh", icon: "keff" },
  { key: "sports", label: "رياضة", category: "Sports", icon: "ball" },
  { key: "unisex", label: "يوني سكس", category: null, icon: "unisex" },
];

/* ==================== Icons ==================== */
const Icon: React.FC<{ type: string }> = ({ type }) => {
  switch (type) {
    case "snow":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <path d="M12 2v20M4 12h16M5 7l14 10M5 17L19 7" />
        </svg>
      );
    case "sun":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M18.4 5.6l1.4-1.4M4.2 19.8l1.4-1.4" />
        </svg>
      );
    case "hoodie":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <path d="M7 8l5-4 5 4v10H7z" />
          <path d="M7 12h10" />
        </svg>
      );
    case "bag":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <path d="M6 7h12l1 4v8H5V11z" />
          <path d="M9 7V5a3 3 0 0 1 6 0v2" />
        </svg>
      );
    case "ring":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <circle cx="12" cy="14" r="6" />
          <path d="M9 5l3-3 3 3" />
        </svg>
      );
    case "keff":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <rect x="4" y="6" width="16" height="12" rx="2" />
          <path d="M6 8l12 8M6 16l12-8" />
        </svg>
      );
    case "ball":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <circle cx="12" cy="12" r="9" />
          <path d="M12 3v18M3 12h18" />
        </svg>
      );
    case "unisex":
      return (
        <svg viewBox="0 0 24 24" width={20} height={20} stroke="currentColor" fill="none">
          <path d="M14 3h7v7" />
          <path d="M21 3l-7 7" />
          <circle cx="9" cy="15" r="5" />
        </svg>
      );
    default:
      return null;
  }
};

/* ==================== Primitives ==================== */
const Section: React.FC<{ title?: string; subtitle?: string; id?: string; children?: React.ReactNode }> = ({ title, subtitle, id, children }) => (
  <section id={id} className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
    {title ? (
      <div className="mb-8 text-center will-change-transform animate-[fadeInUp_500ms_ease]">
        <h2 className="text-3xl md:text-5xl font-semibold tracking-tight">{title}</h2>
        {subtitle ? <p className="mt-3 text-base md:text-lg text-neutral-400">{subtitle}</p> : null}
      </div>
    ) : null}
    {children}
  </section>
);

const Breadcrumbs: React.FC<{ trail: string[] }> = ({ trail }) => (
  <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-6 text-xs text-neutral-400">
    {trail.map((t, i) => (
      <span key={i}>
        {i > 0 && <span className="px-1">/</span>}
        <span className={i === trail.length - 1 ? "text-white" : "hover:text-white cursor-pointer"}>{t}</span>
      </span>
    ))}
  </nav>
);

/* ==================== Header, Loading & Menu ==================== */
const LoadingCurtain: React.FC<{ show: boolean }> = ({ show }) => {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-black">
      <div className="relative flex flex-col items-center">
        <img src={getLogo()} alt="PalStyle" className="h-10 w-auto opacity-95" />
        <div className="mt-4 h-[2px] w-48 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-1/3 animate-[shimmer_1200ms_ease-in-out_infinite] bg-white/60" />
        </div>
      </div>
      <style>{`@keyframes shimmer{0%{transform:translateX(-66%);filter:blur(4px)}50%{filter:blur(2px)}100%{transform:translateX(200%);filter:blur(4px)}}`}</style>
    </div>
  );
};

const Header: React.FC<{ onOpenMenu: () => void; cartCount: number }> = ({ onOpenMenu, cartCount }) => (
  <header className="fixed top-0 inset-x-0 z-30 border-b border-white/10 backdrop-blur bg-black/60">
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <button aria-label="Menu" onClick={onOpenMenu} className="relative w-10 h-10 rounded-xl ring-1 ring-white/10 hover:ring-white/20 transition shadow-[0_0_0_0_rgba(255,255,255,0)] hover:shadow-[0_0_20px_2px_rgba(255,255,255,0.06)]">
        <span className="absolute left-2 right-2 top-3 h-[2px] rounded-full bg-gradient-to-r from-white/60 via-white to-white/60" />
        <span className="absolute left-2 right-2 top-1/2 -translate-y-1/2 h-[2px] rounded-full bg-gradient-to-r from-white/60 via-white to-white/60" />
        <span className="absolute left-2 right-2 bottom-3 h-[2px] rounded-full bg-gradient-to-r from-white/60 via-white to-white/60" />
      </button>
      <a href="#" className="flex items-center gap-2">
        <img src={getLogo()} alt="PalStyle" className="h-6 md:h-7 w-auto" />
      </a>
      <div className="relative w-10 h-10 rounded-xl ring-1 ring-white/10 grid place-items-center hover:ring-white/20 hover:shadow-[0_0_18px_2px_rgba(255,255,255,0.06)] transition">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <circle cx="9" cy="20" r="1"></circle>
          <circle cx="17" cy="20" r="1"></circle>
          <path d="M5 4h2l2 12h8l2-8H7"></path>
        </svg>
        <span className="absolute -top-1 -right-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white text-black">{cartCount}</span>
      </div>
    </div>
  </header>
);

const GlassMenu: React.FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => (
  <div className={`fixed inset-0 z-40 ${open?"pointer-events-auto":"pointer-events-none"}`}>
    <div className={`absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity duration-300 ${open?"opacity-100":"opacity-0"}`} onClick={onClose}/>
    <div className={`absolute right-3 top-3 bottom-3 w-[320px] rounded-2xl ring-1 ring-white/10 bg-[rgba(20,20,20,0.75)] backdrop-blur-xl p-6 transition-all duration-300 ${open?"translate-x-0 opacity-100":"translate-x-4 opacity-0"}`}>
      <div className="flex items-center justify-between">
        <img src={getLogo()} alt="PalStyle" className="h-6"/>
        <button onClick={onClose} className="rounded-xl px-3 py-1.5 text-sm bg-white text-black hover:opacity-90">Close</button>
      </div>
      <nav className="mt-6 space-y-2">
        {[
          {href:'#collections',label:'Collections'},
          {href:'#shop',label:'Shop'},
          {href:'#look',label:'Lookbook'},
          {href:'#about',label:'About'},
        ].map(i=> (
          <a key={i.href} href={i.href} onClick={onClose} className="block group px-4 py-3 rounded-xl ring-1 ring-white/10 hover:ring-white/20 bg-white/0 hover:bg:white/5 transition relative">
            <span className="relative z-10 text-lg">{i.label}</span>
            <span className="pointer-events-none absolute inset-0 rounded-xl shadow-[0_0_30px_6px_rgba(255,255,255,0.06)] opacity-0 group-hover:opacity-100 transition"/>
          </a>
        ))}
      </nav>
    </div>
  </div>
);

/* ==================== Highlights Bar ==================== */
const HighlightsBar: React.FC<{
  items: Highlight[];
  activeCat: string;
  activeSubcat: string;
  onPick: (h: Highlight) => void;
}> = ({ items, activeCat, activeSubcat, onPick }) => (
  <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
    <div className="flex gap-4 overflow-x-auto no-scrollbar">
      {items.map((it) => {
        const isActive = (it.category || "All") === (activeCat || "All") && (!!it.subcategory ? it.subcategory === activeSubcat : activeSubcat === "");
        return (
          <button key={it.key} onClick={() => onPick(it)} className="group flex-shrink-0 w-[84px]">
            <div
              className={`relative w-20 h-20 rounded-full p-[3px] transition-transform ${isActive ? "scale-105" : "scale-100"}`}
              style={{ background: "conic-gradient(from 0deg, #fdfdfd 0%, #004a40 25%, #fdfdfd 50%, #004a40 75%, #fdfdfd 100%)" }}
            >
              <div className="w-full h-full rounded-full bg-black grid place-items-center ring-1 ring-white/15">
                <Icon type={it.icon} />
              </div>
            </div>
            <div className="mt-2 text-center text-xs text-white/90 truncate">{it.label}</div>
          </button>
        );
      })}
    </div>
  </div>
);

/* ==================== Hooks ==================== */
const useReveal = () => {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.classList.add("opacity-0", "translate-y-2");
    const obs = new IntersectionObserver(
      ([ent]) => {
        if (ent.isIntersecting) {
          el.classList.remove("opacity-0", "translate-y-2");
          el.classList.add("animate-[fadeInUp_500ms_ease]");
          obs.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
};

/* ==================== Card & PDP ==================== */
const ImgWithFallback: React.FC<{ src?: string; alt: string; bg: string }> = ({ src, alt, bg }) => {
  const [ok, setOk] = useState<boolean>(false);
  useEffect(() => { setOk(false); }, [src]);
  return (
    <div className="absolute inset-0">
      {src ? (
        <img
          src={src}
          alt={alt}
          onLoad={() => setOk(true)}
          onError={() => setOk(false)}
          className={`w-full h-full object-cover transition-transform duration-500 ${ok ? "opacity-100" : "opacity-0"}`}
        />
      ) : null}
      {!ok && (
        <div
          className="w-full h-full"
          style={{ background: `radial-gradient(60% 60% at 50% 40%, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 45%, transparent 70%), ${bg}` }}
        />
      )}
    </div>
  );
};

const ProductCard: React.FC<{ p: Product; onOpen: (p: Product) => void }> = ({ p, onOpen }) => {
  const ref = useReveal();
  return (
    <div ref={ref} className="group rounded-2xl p-4 bg-gradient-to-b from-neutral-900 to-neutral-950 ring-1 ring-white/10 shadow-xl transition-all duration-300 hover:shadow-2xl">
      <button onClick={() => onOpen(p)} className="block w-full text-left">
        <div className="relative aspect-square w-full rounded-xl overflow-hidden">
          <ImgWithFallback src={p?.image_url} alt={p?.name || "Product"} bg={p?.color || "#0f0f10"} />
          <div className="absolute top-3 left-3 text-[11px] px-2 py-1 rounded-full bg-white/10 ring-1 ring-white/15">{p?.tag || "New"}</div>
        </div>
        <div className="pt-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-white/80">{p?.name || "Product"}</p>
            <p className="text-white font-semibold mt-1">{currency(toNumber(p?.price))}</p>
          </div>
          <span className="text-xs text-neutral-400">{p?.subcategory || p?.category}</span>
        </div>
      </button>
      <div className="mt-3">
        <button onClick={() => onOpen(p)} className="text-sm px-3 py-2 rounded-xl text-black bg-white hover:bg-white/90 transition w-full">
          View
        </button>
      </div>
    </div>
  );
};

const PDPModal: React.FC<{
  product: Product | null;
  onClose: () => void;
  onAdd: (p: Product, size: string, qty: number) => void;
  related: Product[];
}> = ({ product, onClose, onAdd, related }) => {
  const [size, setSize] = useState<string>(product?.sizes?.[0] || "OS");
  const [qty, setQty] = useState<number>(1);
  if (!product) return null;
  return (
    <div className="fixed inset-0 z-40">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="absolute inset-x-0 bottom-0 md:inset-y-8 md:mx-auto md:max-w-3xl bg-neutral-950 rounded-t-3xl md:rounded-3xl ring-1 ring-white/10 overflow-hidden">
        <div className="grid md:grid-cols-2 gap-0">
          <div className="p-6 md:p-8 border-b md:border-b-0 md:border-r border-white/10">
            <div className="relative aspect-square w-full rounded-xl overflow-hidden ring-1 ring-white/10 bg-gradient-to-b from-neutral-900 to-neutral-950">
              <ImgWithFallback src={product.image_url} alt={product.name} bg={product.color} />
            </div>
          </div>
          <div className="p-6 md:p-8">
            <Breadcrumbs trail={["الرئيسية", "المتجر", product.category, product.name]} />
            <h3 className="mt-2 text-2xl md:text-3xl font-semibold">{product.name}</h3>
            <div className="mt-2 text-lg">{currency(toNumber(product.price))}</div>
            <p className="mt-3 text-sm text-neutral-400">SKU: {product.sku} • In stock</p>

            <div className="mt-5">
              <p className="text-sm text-neutral-300 mb-2">المقاس</p>
              <div className="flex flex-wrap gap-2">
                {(product.sizes || ["OS"]).map((s) => (
                  <button
                    key={s}
                    onClick={() => setSize(s)}
                    className={`px-3 py-2 rounded-lg text-sm ring-1 ${size === s ? "bg-white text-black ring-white" : "ring-white/15 hover:bg-white/10"}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2">
              <p className="text-sm text-neutral-300">الكمية</p>
              <div className="flex items-center ring-1 ring-white/15 rounded-lg overflow-hidden">
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-3 py-2 hover:bg-white/10">-</button>
                <span className="px-3 py-2 text-sm min-w-[32px] text-center">{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} className="px-3 py-2 hover:bg:white/10">+</button>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-2">
              <button onClick={() => onAdd(product, size, qty)} className="px-5 py-3 rounded-xl bg:white text-black text-sm hover:opacity-90 bg-white">
                أضف إلى السلة
              </button>
              <button onClick={onClose} className="px-5 py-3 rounded-xl bg-white/10 ring-1 ring-white/15 text-sm hover:bg-white/15">
                إغلاق
              </button>
            </div>

            <div className="mt-6 divide-y divide-white/10 text-sm">
              <details className="py-3" open>
                <summary className="cursor-pointer text-neutral-200">التفاصيل</summary>
                <p className="mt-2 text-neutral-400">قطن فاخر، ملمس ناعم، راحة يومية.</p>
              </details>
              <details className="py-3">
                <summary className="cursor-pointer text-neutral-200">الشحن والإرجاع</summary>
                <p className="mt-2 text-neutral-400">شحن سريع، وإرجاع سهل خلال 14 يومًا.</p>
              </details>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ==================== Faux 3D Box ==================== */
const BeveledBox: React.FC = () => (
  <div className="relative h-full w-full flex items-center justify-center">
    <style>{`
      @keyframes spinY { to { transform: rotateY(360deg); } }
      @keyframes floatY { 0%,100% { transform: translateY(0px); } 50% { transform: translateY(-8px); } }
    `}</style>
    <div
      className="relative rounded-[22px] w-[280px] h-[340px] bg-neutral-800/90 border border-white/10 shadow-[0_20px_60px_rgba(0,0,0,0.6)]"
      style={{ transformStyle: "preserve-3d", animation: "spinY 18s linear infinite, floatY 4s ease-in-out infinite" }}
    >
      <div className="absolute -inset-0.5 rounded-[26px] bg-[radial-gradient(50%_50%_at_50%_0%,rgba(255,255,255,0.14),transparent)] blur-md pointer-events-none" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[160px] h-[160px] rounded-2xl bg-white/90" />
      <div className="absolute left-1/2 top-[76%] -translate-x-1/2 w-[160px] h-[34px] rounded-xl bg-black/90" />
    </div>
  </div>
);

/* ==================== Category Tabs (filters + search) ==================== */
const CategoryTabs: React.FC<{
  categories: string[];
  active: string;
  onChange: (c: string) => void;
  sort: string;
  setSort: (s: string) => void;
  tagFilter: string;
  setTagFilter: (t: string) => void;
  sizeFilter: string;
  setSizeFilter: (s: string) => void;
  availableTags: string[];
  availableSizes: string[];
  subcatsForActive: string[];
  activeSubcat: string;
  onPickSubcat: (s: string) => void;
  search: string;
  setSearch: (s: string) => void;
}> = ({
  categories,
  active,
  onChange,
  sort,
  setSort,
  tagFilter,
  setTagFilter,
  sizeFilter,
  setSizeFilter,
  availableTags,
  availableSizes,
  subcatsForActive,
  activeSubcat,
  onPickSubcat,
  search,
  setSearch,
}) => (
  <div className="sticky top-16 z-20 bg-black/70 backdrop-blur border-b border-white/10">
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3">
      <div className="flex flex-wrap items-center gap-2">
        {["All", ...categories].map((c) => (
          <button
            key={c}
            onClick={() => onChange(c)}
            className={`px-4 py-2 rounded-xl text-sm ring-1 transition ${active === c ? "bg-white text-black ring-white" : "bg-white/0 text:white ring-white/15 hover:bg-white/10 text-white"}`}
          >
            {c}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2">
          <div className="relative">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search products…"
              className="w-[180px] md:w-[220px] bg-black/0 text-sm ring-1 ring-white/15 rounded-lg px-3 py-2 placeholder:text-neutral-500"
            />
            <span className="pointer-events-none absolute right-2 top-2.5 text-[11px] text-neutral-500">⌘K</span>
          </div>
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-black/0 text-sm ring-1 ring-white/15 rounded-lg px-3 py-2">
            <option value="new">New</option>
            <option value="price-asc">Price ↑</option>
            <option value="price-desc">Price ↓</option>
          </select>
          <select value={tagFilter} onChange={(e) => setTagFilter(e.target.value)} className="bg-black/0 text-sm ring-1 ring-white/15 rounded-lg px-3 py-2">
            <option value="">All Tags</option>
            {availableTags.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <select value={sizeFilter} onChange={(e) => setSizeFilter(e.target.value)} className="bg-black/0 text-sm ring-1 ring-white/15 rounded-lg px-3 py-2">
            <option value="">All Sizes</option>
            {availableSizes.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>
      {active !== "All" && subcatsForActive.length ? (
        <div className="mt-3 flex flex-wrap gap-2">
          {subcatsForActive.map((sc) => (
            <button
              key={sc}
              onClick={() => onPickSubcat(activeSubcat === sc ? "" : sc)}
              className={`px-3 py-1.5 rounded-lg text-xs ring-1 ${activeSubcat === sc ? "bg-white text-black ring-white" : "ring-white/15 hover:bg-white/10"}`}
            >
              {sc}
            </button>
          ))}
          {activeSubcat && (
            <button onClick={() => onPickSubcat("")} className="px-3 py-1.5 rounded-lg text-xs ring-1 ring-white/15 hover:bg-white/10">Clear sub-type</button>
          )}
        </div>
      ) : null}
    </div>
  </div>
);

/* ==================== Collections ==================== */
const Collections: React.FC<{ onPick: (h: Highlight) => void }> = ({ onPick }) => (
  <Section id="collections" title="Collections" subtitle="Tap a tile to shop the drop.">
    <div className="grid md:grid-cols-3 gap-4">
      {HIGHLIGHTS.filter((h) => h.category).slice(0, 6).map((h) => (
        <button key={h.key} onClick={() => onPick(h)} className="relative aspect-[3/2] rounded-3xl overflow-hidden ring-1 ring-white/10 group">
          <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-white/0" />
          <div className="absolute inset-0 transition-transform duration-500 group-hover:scale-[1.03]" style={{ background: "radial-gradient(60%_60%_at_50%_40%,rgba(255,255,255,.06),transparent 60%),#0f0f10" }} />
          <div className="absolute left-5 top-5 px-3 py-1.5 rounded-xl bg-white text-black text-sm flex items-center gap-2">
            <Icon type={h.icon} />
            <span>{h.label}</span>
          </div>
          <div className="absolute inset-0 grid place-items-center pointer-events-none">
            <div className="w-1/2 h-1/2 rounded-2xl bg-white/5 border border-white/10 shadow-[0_0_40px_rgba(255,255,255,0.08)]" />
          </div>
        </button>
      ))}
    </div>
  </Section>
);

/* ==================== CSV Uploader ==================== */
const CSVUploader: React.FC<{ onIngest: (rows: Product[]) => void }> = ({ onIngest }) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const parseCSV = (text: string): Product[] => {
    const lines = text.split(/\\r?\\n/).filter(Boolean);
    if (!lines.length) return [];
    const headers = lines[0].split(",").map((h) => h.trim().toLowerCase());
    return lines.slice(1).map((ln, i) => {
      const cols = ln.split(",");
      const obj: Record<string, string> = {};
      headers.forEach((h, idx) => (obj[h] = (cols[idx] || "").trim()));
      const id = Date.now() + i;
      const sizes = obj.sizes ? obj.sizes.split("|").map((s) => s.trim()).filter(Boolean) : ["OS"];
      return {
        id,
        name: obj.name || `Item ${id}`,
        price: obj.price || "₺0",
        tag: obj.tag || "New",
        color: obj.color || "#0f0f10",
        category: obj.category || "Misc",
        subcategory: obj.subcategory || undefined,
        sku: obj.sku || `SKU-${id}`,
        sizes,
        image_url: obj.image_url || undefined,
      } as Product;
    });
  };
  const onFile = async (f: File) => {
    const text = await f.text();
    onIngest(parseCSV(text));
  };
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center gap-3 text-sm">
        <button onClick={() => inputRef.current?.click()} className="px-4 py-2 rounded-xl bg-white text-black hover:opacity-90">Import CSV</button>
        <span className="text-neutral-400">Upload Trendyol CSV: name,price,tag,color,category,sku,sizes[,subcategory,image_url]</span>
        <input ref={inputRef} type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }} />
      </div>
    </div>
  );
};

/* ==================== Page ==================== */
export default function App() {
  const [catalog, setCatalog] = useState<Product[]>(seedProducts);
  const [activeCat, setActiveCat] = useState<string>("All");
  const [activeSubcat, setActiveSubcat] = useState<string>("");
  const [sort, setSort] = useState<string>("new");
  const [tagFilter, setTagFilter] = useState<string>("");
  const [sizeFilter, setSizeFilter] = useState<string>("");
  const [search, setSearch] = useState<string>("");
  const [selected, setSelected] = useState<Product | null>(null);
  const [cartCount, setCartCount] = useState<number>(2);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const [tests, setTests] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [toasts, setToasts] = useState<{ id: number; text: string; kind: "ok" | "err" }[]>([]);

  // Toast helpers
  const addToast = (text: string, kind: "ok" | "err" = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((arr) => [...arr, { id, text, kind }]);
    setTimeout(() => setToasts((arr) => arr.filter((t) => t.id !== id)), 2600);
  };
  async function postWithRetry(url: string, body: any, max = 3) {
    let lastErr: any;
    for (let i = 0; i < max; i++) {
      try {
        const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        if (!res.ok) throw new Error("HTTP " + res.status);
        return true;
      } catch (e) {
        lastErr = e;
        await new Promise((r) => setTimeout(r, 400 * Math.pow(2, i)));
      }
    }
    throw lastErr;
  }

  // Inject brand palette once
  useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty("--brand-green", "#004a40");
    r.style.setProperty("--brand-ink", "#262628");
    r.style.setProperty("--brand-paper", "#fdfdfd");
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 900);
    return () => clearTimeout(t);
  }, []);

  const categories = useMemo(() => uniq(catalog.map((p) => p.category)), [catalog]);
  const availableTags = useMemo(() => uniq(catalog.map((p) => p.tag)), [catalog]);
  const availableSizes = useMemo(() => uniq(catalog.flatMap((p) => p.sizes || [])), [catalog]);

  const subcatsForActive = useMemo(() => {
    if (activeCat === "All") return [] as string[];
    return uniq(catalog.filter((p) => p.category === activeCat).map((p) => p.subcategory || "")).filter(Boolean) as string[];
  }, [catalog, activeCat]);

  const listed = useMemo(() => {
    let arr = [...catalog];
    if (activeCat !== "All") arr = arr.filter((p) => p.category === activeCat);
    if (activeSubcat) arr = arr.filter((p) => (p.subcategory || "") === activeSubcat);
    if (tagFilter) arr = arr.filter((p) => (p.tag || "").toLowerCase() === tagFilter.toLowerCase());
    if (sizeFilter) arr = arr.filter((p) => (p.sizes || []).includes(sizeFilter));
    if (search.trim()) arr = arr.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()));
    if (sort === "price-asc") arr.sort((a, b) => toNumber(a.price) - toNumber(b.price));
    if (sort === "price-desc") arr.sort((a, b) => toNumber(b.price) - toNumber(a.price));
    return arr;
  }, [catalog, activeCat, activeSubcat, sort, tagFilter, sizeFilter, search]);

  const handleAdd = async (p: Product, size: string, qty: number) => {
    setCartCount((c) => c + qty);
    setSelected(null);
    const payload = { product: p.name, size, qty, price: toNumber(p.price), sku: p.sku };
    try {
      await postWithRetry("https://script.google.com/macros/s/1VcaMmRXIp9s7GCJe02wcA1Li4mXToZEQosVCAfJAKMKLwzXO0rl7ggJz/exec", payload, 3);
      addToast("✔ تم إضافة الطلب وإرساله", "ok");
    } catch (e) {
      console.error("❌ Webhook failed after retries", e);
      addToast("⚠ تعذّر الإرسال، سنحاول لاحقًا", "err");
    }
  };

  const relatedFor = (p: Product) => catalog.filter((x) => x.id !== p.id && (x.category === p.category || x.subcategory === p.subcategory || x.tag === p.tag));
  const ingestRows = (rows: Product[]) => { if (Array.isArray(rows) && rows.length) setCatalog((old) => [...old, ...rows]); };
  const handleHighlightPick = (it: Highlight) => {
    if (!it.category) { setActiveCat("All"); setActiveSubcat(""); }
    else { setActiveCat(it.category); setActiveSubcat(it.subcategory || ""); }
    document.getElementById("shop")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  useEffect(() => {
    const out: any[] = [];
    out.push({ test: "catalog is array", pass: Array.isArray(catalog) });
    out.push({ test: ">= 4 items", pass: catalog.length >= 4, details: String(catalog.length) });
    out.push({ test: "price parse ok (seed)", pass: catalog.every((p) => toNumber(p.price) > 0) });
    out.push({ test: "search filters name", pass: listed.every((p) => p.name.toLowerCase().includes(search.toLowerCase()) || !search) });
    out.push({ test: "toNumber ₺1199", pass: toNumber("₺1199") === 1199 });
    out.push({ test: "toNumber 1.299,00", pass: toNumber("1.299,00") === 1299 });
    out.push({ test: "toNumber 1,299", pass: toNumber("1,299") === 1299 });
    out.push({ test: "toNumber 1.234", pass: toNumber("1.234") === 1234 });
    out.push({ test: "toNumber 1.299,50", pass: Math.abs(toNumber("1.299,50") - 1299.5) < 1e-6 });
    out.push({ test: "sort price-asc", pass: (() => { const arr=[{price:"₺30"},{price:"₺10"},{price:"₺20"}]; const s=[...arr].sort((a:any,b:any)=>toNumber(a.price)-toNumber(b.price)); return toNumber(s[0].price)===10 && toNumber(s[2].price)===30; })() });
    setTests(out);
  }, [catalog, listed, search]);

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <LoadingCurtain show={loading} />
      <Header onOpenMenu={() => setMenuOpen(true)} cartCount={cartCount} />
      <GlassMenu open={menuOpen} onClose={() => setMenuOpen(false)} />

      <div className="pt-16" />

      {/* Hero */}
      <div className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <p className="text-sm tracking-wider text-white/60">PalStyle — Be Stylish. Be Free.</p>
              <h1 className="mt-2 text-3xl md:text-5xl font-semibold leading-tight">هوية معاصرة بلمسة الكوفية. خامات فاخرة، تفاصيل دقيقة، وراحة يومية.</h1>
              <p className="mt-3 text-neutral-400 max-w-xl">تصميم ثلاثي الأبعاد مع موشن ناعم — متجر رسمي سريع وخفيف، جاهز للربط مع Trendyol وMeta Pixel والدفع.</p>
              <div className="mt-6 flex gap-3">
                <a href="#shop" className="px-5 py-3 rounded-xl bg-white text-black text-sm hover:opacity-90">تسوّق الآن</a>
                <a href="#collections" className="px-5 py-3 rounded-xl bg-white/10 ring-1 ring-white/15 text-sm hover:bg-white/15">المجموعات</a>
              </div>
            </div>
            <div className="hidden md:block"><BeveledBox /></div>
          </div>
        </div>
      </div>

      <HighlightsBar items={HIGHLIGHTS} activeCat={activeCat} activeSubcat={activeSubcat} onPick={handleHighlightPick} />
      <Collections onPick={handleHighlightPick} />

      <CategoryTabs
        categories={categories}
        active={activeCat}
        onChange={setActiveCat}
        sort={sort}
        setSort={setSort}
        tagFilter={tagFilter}
        setTagFilter={setTagFilter}
        sizeFilter={sizeFilter}
        setSizeFilter={setSizeFilter}
        availableTags={availableTags}
        availableSizes={availableSizes}
        subcatsForActive={subcatsForActive}
        activeSubcat={activeSubcat}
        onPickSubcat={setActiveSubcat}
        search={search}
        setSearch={setSearch}
      />

      <Section id="shop" title="Shop" subtitle="Curated pieces. Subtle motion. PalStyle quality.">
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {listed.map((p) => (
            <ProductCard key={p.id + p.sku} p={p} onOpen={(pp) => setSelected(pp)} />
          ))}
        </div>
      </Section>

      <CSVUploader onIngest={ingestRows} />
      <PDPModal product={selected} onClose={() => setSelected(null)} onAdd={handleAdd} related={selected ? relatedFor(selected) : []} />

      {/* Toasts */}
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[70] grid place-items-center gap-2">
        {toasts.map((t) => (
          <div key={t.id} className={`pointer-events-auto px-4 py-2 rounded-xl text-sm ring-1 shadow-2xl ${t.kind === "ok" ? "bg-white text-black ring-white" : "bg-red-500 text-white ring-red-300"}`}>
            {t.text}
          </div>
        ))}
      </div>

      <footer className="mt-10 pb-12 text-center text-xs text-neutral-500">
        <div className="mb-2">© {new Date().getFullYear()} PalStyle — Be Stylish. Be Free.</div>
        <details className="mx-auto mt-2 max-w-3xl text-left ring-1 ring-white/10 rounded-lg p-4">
          <summary className="cursor-pointer text-neutral-300">Smoke Tests</summary>
          <ul className="mt-2 space-y-1 text-xs">
            {tests.map((t, i) => (
              <li key={i} className={t.pass ? "text-emerald-400" : "text-red-400"}>
                <span className="font-mono">[{i + 1}]</span> {t.test} {t.details ? <em className="text-neutral-400">— {t.details}</em> : null}
              </li>
            ))}
          </ul>
        </details>
      </footer>
    </div>
  );
}
